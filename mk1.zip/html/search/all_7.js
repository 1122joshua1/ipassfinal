var searchData=
[
  ['updatefixture',['updatefixture',['../classdmx512.html#a0c31875d2fed8d85cf5091f30eddd697',1,'dmx512']]]
];
