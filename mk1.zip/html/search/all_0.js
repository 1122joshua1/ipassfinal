var searchData=
[
  ['addtopatch',['addtopatch',['../classdmx512.html#a6a6dca3c6513b17fa73426891b82fd05',1,'dmx512']]]
];
